module timerModN_tb;

reg clk = 0;
reg rst_n = 1;
wire [3:0] count;

timerModN #(
  .st0(3),
  .tmcount0(4),
  .tmcount1(9))
  timer 
  (
    .clk_i(clk),
    .nRst_i(rst_n),
    .count_o(count)
  );
always
  #5 clk = ~clk;
initial begin
  $display("time  Count_w");     // output table header
  $monitor("%4d  %2d",         // output table signal formatting
  $time, count);
  rst_n = 0;
  #5;
  rst_n = 1;

  #500 $finish;
end

endmodule


