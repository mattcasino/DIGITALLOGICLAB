module timerModN #(parameter st0 = 26, tmcount0 = 50_000_000 - 1, tmcount1 = 9)(input clk_i, nRst_i, output reg [3:0] count_o);

reg [st0-1:0] cnt_r;
always @(posedge clk_i or negedge nRst_i)
begin
  if(!nRst_i)
  begin
    cnt_r <= 0;
    count_o <= 0;
  end
  else if( cnt_r == tmcount0 )
  begin
    cnt_r <= 0;
    if(count_o == tmcount1)
      count_o <= 0;
    else
      count_o <= count_o + 1'b1;
  end
  else
    cnt_r <= cnt_r + 1'b1;
end
endmodule
