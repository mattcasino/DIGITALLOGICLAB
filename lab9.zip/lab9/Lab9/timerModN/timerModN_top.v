module timerModN_top(input CLOCK_50, input KEY0, output [6:0] HEX0);
wire clean_in;
wire [3:0] count;
debouncer db (
  .clk_i (CLOCK_50),
  .noisy_i (KEY0),
  .clean_o (clean_in) );

timerModN tm(
  .clk_i (CLOCK_50),
  .nRst_i(clean_in),
  .count_o(count) );

dec7seg seg(
  .bcd_i(count),
  .disp_o(HEX0) );
endmodule
    

