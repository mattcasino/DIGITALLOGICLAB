// CPEN230L lab 7 part 3, MUX/Decoder test bench
// Matthew Casino, 03/16/2026
module mux_disp_top_tb; // testbench top level, no inputs/outputs
reg [17:0] SW_sim; // simulated input switches
wire [6:0] HEX0_sim; // simulated output 7-segment display segments
mux_disp_top DUT( // instantiate the DUT
  .SW (SW_sim),
  .HEX0 (HEX0_sim));
initial begin // test bench stimulus
  SW_sim[14: 0] = 15'o01234; // use octal to deal with 3-bit groups
  SW_sim[17:15] = 3'o0; // @t=0 output = SW[14:12] = 0 = 1000000
  #5 SW_sim[17:15] = 3'o1; // @t=5 output = SW[11: 9] = 1 = 1111001
  #5 SW_sim[17:15] = 3'o2; // @t=10
  #5 SW_sim[17:15] = 3'o3; // @t=15
  #5 SW_sim[17:15] = 3'o4; // @t=20
  #5 SW_sim[14: 0] = 15'o56777; // @t=25
  #5 SW_sim[17:15] = 3'o0; // @t=30
  #5 SW_sim[17:15] = 3'o1; // @t=35
  #5 SW_sim[17:15] = 3'o2; // @t=35
  #5 $finish; // @t=40, end simulation
end
initial begin // test bench response
  $display("time HEX0 bit 6543210");
  $display("==== ================");
  $monitor("%4d %7b", $time, HEX0_sim);
end
endmodule
