// CPEN 230L lab 7
// Matthew Casino, 3/16/2026
module mux_disp_top( input[ 17:0] SW, output [6:0] HEX0 );
wire [2:0] mux_o;
mux3w_5to1 mux (
  .SW (SW),
  .LEDG (mux_o));
oct7seg sevenseg (
  .c_i (mux_o),
  .disp_o ( HEX0 ));
endmodule
